
require('dotenv').config({ path: './.env' });

// Debug to confirm environment variables are loaded
console.log('Loaded Environment Variables:', {
  PORT: process.env.PORT,
  DB_HOST: process.env.DB_HOST,
  DB_PORT: process.env.DB_PORT,
  DB_USER: process.env.DB_USER,
  DB_NAME: process.env.DB_NAME,
  JWT_SECRET: process.env.JWT_SECRET
});

const express = require('express');
const cors = require('cors');
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger');
const sequelize = require('./config/database');
const authRoutes = require('./routes/auth');
const eventRoutes = require('./routes/events');
const initRoutes = require('./routes/init');
const speakerRoutes = require('./routes/speakers');
const attendeeRoutes = require('./routes/attendees');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/init', initRoutes);
app.use('/doc', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use('/api/speakers', speakerRoutes);
app.use('/api/attendees', attendeeRoutes);

// Test database connection and start server
sequelize.authenticate()
  .then(() => {
    console.log('Database connection successful');
    return sequelize.sync({ force: true }); // Sync models (drops and recreates tables)
  })
  .then(() => {
    app.listen(process.env.PORT || 3000, () => {
      console.log(`Backend running on port ${process.env.PORT || 3000}`);
    });
  })
  .catch(err => {
    console.error('Database connection failed:', err);
  });